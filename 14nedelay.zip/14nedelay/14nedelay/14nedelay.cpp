﻿#include <iostream>
#include <ctime>
#include <cmath>
using namespace std;

//Тема: Указатели
//Домашнее задание 1
//Задание 1. Даны два массива : А[M] и B[N](M и N вводятся  с клавиатуры).Необходимо создать третий массив минимально возможного размера,в котором нужно собрать
//элементы массива A, которые включаются в массив B без повторений.
//Задане мне не понятно??

//Тема: Указатели.Передача параметров
//Домашнее задание 2
//Задание 1. Написать следующие функции для работы
//с динамическим массивом :
//■ Функция распределения динамической памяти.
//■ Функция инициализации динамического массива.
//■ Функция печати динамического массива.
//■ Функция удаления динамического массива.
//■ Функция добавления элемента в конец массива.
//■ Функция вставки элемента по указанному индексу.
//■ Функция удаления элемента по указанному индексу.
//Задание 2. Написать функцию, которая получает указатель на динамический массив и его размер.Функция
//должна удалить из массива все простые числа и вернуть
//указатель на новый динамический массив.
//Задание 3. Написать функцию, которая получает указатель
//на статический массив и его размер.Функция распределяет положительные, отрицательные и нулевые элементы
//в отдельные динамические массивы.

void HeapAllocation(int* arrN, int sizeN)// функция выделения динамической памяти
{
    int* arrN = new int[sizeN];//правильно?
}
void Deletearray(int*arrN)//функция удаления динамического массива
{
    delete[] arrN;//правильно?
}

void FillTheArray(int* arrN,int &sizeN)//заполняем массив рандомнмными значениями
{ 
    bool flag;
    for (int i = 0; i < sizeN;)
    {
        flag = false;//
        int newrandom = rand() % 20;//
      
        for (int j = 0; j < i; ++j)//убираем повторения
        {
            if (arrN[j] == newrandom)
            {
                flag = true;
                break;
            }
        }
        if (!flag)
        {
            arrN[i] = newrandom;
            i++;
        }
    }
}
void SortingAnArray(int* arrN, int  &sizeN)//пузырьковая сортировка
{

    int x;

    for (int i = 0; i < sizeN; i++)// i - номер прохода
    { 
        for (int j = sizeN - 1; j > i; j--) // внутренний цикл прохода
        { 
       
            if (arrN[j - 1] > arrN[j]) {
                x = arrN[j - 1];
                arrN[j - 1] = arrN[j];
                arrN[j] = x;
            }
        }
    }
}

void OutputArray(int* arrN, int &sizeN)
{
    for (int  i = 0; i < sizeN; i++)
    {
        cout << arrN[i] << "\t";
    }
    cout << endl;
}

bool prostae_chislo(int n) 
{
    bool result(true);

    if ((n == 2) || (n == 3))
        result = true;
    else {
        for (int i = 2; i <= floor(sqrt(n)); ++i)
            if (n % i == 0)
            {
                result = false;
                break;
            }
    }
    return (result && (n != 1));
}

int* proverca(int* ArrN, int sizeN)
{

    int count = 0;
    for (int i = 0; i < sizeN; ++i) {
        if (!prostae_chislo(ArrN[i]))
            ++count;
    }

    int* arrB = new int[count];

    int j = 0;
    for (int i = 0; i < sizeN; ++i)
        if (!prostae_chislo(ArrN[i]))
            arrB[j++] = ArrN[i];

    for (int j = 0; j < count; j++)
        cout << arrB[ j] << " ";
    return arrB;
    delete[] arrB;
}

int main()
{
    srand(time(NULL));

   int sizeA,sizeB,sizeC;
   cout << " Input size arrayA: ";
    cin >> sizeA; // вводим размер масива А
    cout << " Input size arrayB: ";
    cin >> sizeB; // вводим развер массива В

    int* arrayA = new int [sizeA];//создаем динамический массив А
    int* arrayB = new int [sizeB];//создаем динамический массив В

    if (sizeA > sizeB)//ищем наименьший размер массивов А и В и присваеваем его третьему массиву С
        sizeC = sizeB;
    else if (sizeA < sizeB)
        sizeC = sizeA;
    else if (sizeA == sizeB)
        sizeC = sizeA;

    int* arrayC = new int[sizeC];//создаем третий массив под значения из двух предыдущих массивов

    FillTheArray(arrayA, sizeA);//заполняем рэндомно массив А
    cout << "\n";
    FillTheArray(arrayB, sizeB);//заполняем рэндомно массив В
    cout << "\n";
    FillTheArray(arrayC, sizeC);//заполняем рэндомно массив C

    cout << "\nOutput random array: \n" << endl;

    OutputArray(arrayA, sizeA);//выводим рандомный массив A
    cout << "\n";
    OutputArray(arrayB, sizeB);//выводим рандомный массив B
    cout << "\n";
    OutputArray(arrayC, sizeC);//выводим рандомный массив C

    cout << "\n=================================================\n";

    SortingAnArray(arrayA, sizeA);//сортируем первый массив A
    SortingAnArray(arrayB, sizeB);//сортируем второй массив B
    SortingAnArray(arrayC, sizeC);//сортируем третий массив C

    cout << "\nOutput sorting array: \n" << endl;

    OutputArray(arrayA,sizeA);//выводим отсортированный массив A
    cout << "\n";
    OutputArray(arrayB,sizeB);//выводим отсортированный массив B
    cout << "\n";
    OutputArray(arrayC,sizeC);//выводим отсортированный массив C
    
  delete [] arrayA;//обязательно удаляем первыйА массив 
  delete [] arrayB;//обязательно удаляем второйВ массив
  delete [] arrayC;//обязательно удаляем третийC массив
 
}
