#pragma once
#include<iostream>
using namespace std;

void txt
{
	cout << "hello world ";
}