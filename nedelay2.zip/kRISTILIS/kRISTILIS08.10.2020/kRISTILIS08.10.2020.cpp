﻿
#include <iostream>
using namespace std;

int main()
{
	//неделя 2.
	//Задание 1. Заданы три сопротивлении R1, R2, R3.Вычислить значение сопротивления R0 по формуле : 
	//1 / R0 =1 / R1 + 1 / R2 + 1 / R3.Контрольный пример : R1 = 2, R2 = 4, R3 = 8, R0 = 1.142857.
	float r0, r1, r2, r3;
	cout << "r1= ";
	cin >> r1;
	cout << "r2= ";
	cin >> r2;
	cout << "r3= ";
	cin >> r3;
	r0 = 1 / (1 / r1 + 1 / r2 + 1 / r3);
	cout << " r0= " << r0 << endl;

	//неделя 2.
	//Задание 2. По заданной длине окружности найти площадь круга по формуле S = pi * R2, 
	//радиус вычислить из формулы длины окружности : L = 2 * pi * R.Примечание : pi = 3.14.
	float r, r2;
	cout << "vvedite-r2 ";
	cin >> r2;
	cout << "vvedite-r  ";
	cin >> r;

	float S, L;
	const float pi = 3.14;

	S = pi * r2;
	cout << "plochad kruga S = " << S << endl;

	L = 2 * pi * r;
	cout << "dlina okrugno L = " << L << endl;

	//неделя2
	//Задание 3. Вычислить пройденное расстояние при прямолинейном равноускоренном движении по формуле 
	//S =v * t + (a * t2) / 2, где v — скорость, t — время, а — ускорение.
	float S, v, t, a;
	cout << "skorost   v= ";
	cin >> v;
	cout << "vremay    t= ";
	cin >> t;
	cout << "uskorenie a= ";
	cin >> a;
	S = v * t + (a * t * t);
	cout << "S== " << S << endl;

	//неделя2
	//Задание 1. Пользователь вводит с клавиатуры время
	//в секундах.Необходимо написать программу, которая
	//переведет введенные пользователем секунды в часы,минуты, секунды и выводит их на экран.
	int sek;
	cout << "sek= ";
	cin >> sek;
	int chas, min;
	chas = sek / 3600;
	min = (sek - chas * 3600) / 60;
	sek = sek % 60;
	cout << chas << "chas  " << min << "min " << "sek " << sek;

	//неделя2
	//Задание 2. Написать программу, которая преобразует
	//введенное с клавиатуры дробное число в денежный формат.Например, число 12, 5 должно быть преобразовано
	//к виду 12 грн 50 коп.
	double x;
	cout << " ";
	cin >> x;
	int y = x;
	double z = (x - y) * 100;
	cout << y << " rub   " << z << " kop   ";

	// задание 3. Написать программу, вычисляющую, с какойскоростью бегун пробежал дистанцию. Рекомендуемый
	//вид экрана во время выполнения программы приведен ниже:
	//вид экрана во время выполнения программы приведен ниже :
	//■ Вычисление скорости бега.
	//■ Введите длину дистанции(метров) = 1000.
	//■ Введите время(мин.сек) = 3.25.
	//■ Дистанция : 1000 м.
	//■ Время : 3 мин 25 сек = 205 сек.
	//■ Вы бежали со скоростью : 17.56 км / ч.

	int dist;
	double vrem, min, sek, sek2, speed;


	cout << "\tvicheslenie ckorosti bega\t" << endl;

	cout << "vvedite dlinu distancii(metrov)= ";
	cin >> dist;
	cout << "vvedite vremay(min.sek)= ";
	cin >> vrem;

	min = int(vrem) * 60;
	sek = (vrem - int(vrem)) * 100;
	sek2 = min + sek;

	cout << "Distanciya:  " << dist << " m " << endl;
	cout << "vremay    :  " << min / 60 << " min " << sek << " sek " << " = " << sek2 << " sek " << endl;

	speed = dist / (sek2 / 3.600);
	cout << "vi begali so skorostiu = " << speed << "km/h";


	//Задание 4. Пользователь указывает цену одной минуты
	//исходящего звонка с одного мобильного оператора другому, а также продолжительность разговора в минутах
	//и секундах.Необходимо вычислить денежную сумму на которую был произведен звонок.
	double min, min2, sek, sek2, sum, cena, vrem;
	cout << "cena 1 minuti = ";
	cin >> cena;
	cout << "prodoljitelnost razgovora(v min i sek) = ";
	cin >> vrem;
	min = int(vrem) * 60;
	sek = (vrem - int(vrem)) * 100;
	sek2 = min + sek;
	cena /= 60;
	cout << "itogo za ragovor:  " << min / 60 << " min " << sek << " sek " << " = " << sek2 << " sek " << " == " << cena * sek2 << endl;

	//Задание 5. Написать программу, которая преобразует//введенное пользователем количество дней в количество
	//полных недель и оставшихся дней.Например, пользователь ввел 17 дней, программа должна вывести на экран
	//2 недели и 3 дня.

	double kday, day, sum;
	long long int week;

	cout << " vvedite kol-vo dnei :  ";
	cin >> kday;
	week = kday / 7;
	day = kday - (week * 7);
	cout << week << " ned " << day << " dnay(ei) ";

}