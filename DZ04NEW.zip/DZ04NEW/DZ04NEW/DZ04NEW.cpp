﻿#include <iostream>
using namespace std;
  int main()
  {
        //Тема: Логические операторы и операторы ветвлений
         // Домашнее задание 1
         //Задание 1. Пользователь вводит с клавиатуры целое шестизначное число.Написать программу, которая определяет,
         //является ли введенное число — счастливым(Счастливым считается шестизначное число, у которого сумма первых 3 цифр равна сумме вторых трех цифр).Если пользователь
         // ввел не шестизначное число — сообщение об ошибке.
        //long a, b, a1, a2, a3, a4, a5, a6; // a - шестизначное число, а1-а6 - цыфри числа, которые получим путем деления с остачей
        //cout << "vvedite 6ti znachnoe chiso: ";
        //cin >> a;
        //b = a;
        //a1 = a / 100000; b = a % 100000;
        //a2 = b / 10000; b %= 10000;
        //a3 = b / 1000; b %= 1000;
        //a4 = b / 100; b %= 100;
        //a5 = b / 10; b %= 10;
        //a6 = b;
        //if (a<100000 || a > 999999)
        //    cout << "ne korrektnii nomer " << endl;
        //else if ((a1 + a2 + a3) == (a4 + a5 + a6))
        //        cout << "pobeda" << endl;
        //    else
        //        ((a1 + a2 + a3) != (a4 + a5 + a6));
        //cout << "proigrush " << endl;
  // Задание 2. Пользователь вводит четырехзначное число.Необходимо поменять в этом числе 1 и 2 цифры, а также
  // 3 и 4 цифры.Если пользователь вводит не четырехзначное число — вывести сообщение об ошибке.
      /*  int q,a, b, c, d;
        cout << "vvedite 4x znachnoe chislo ->" << endl;
        cin >> q;

        d = q % 10;
        q /= 10;
        c = q % 10;
        q /= 10;
        b = q % 10;
        q /= 10;
        a = q % 10;

        if (q<1000 || 9999>q)
            cout << "stop" << endl;
        else
        cout << b << a << d << c;*/
  //Задание 3. Пользователь вводит с клавиатуры 7 целых чисел.Напишите программу, которая определяет максимальное из этих 7 чисел(Подсказка — решение должно быть простым).
     /* int num;
      int maxNum = 0;
         for (int i = 1; i <= 7; i++)
        {
            cout << "input 7 number " << i << " : ";
            cin >> num;

            if (maxNum < num)
            {
                maxNum = num;
            }
        }
        cout << endl;
        '
        cout << "Max number: " << maxNum << endl; 
       */
 // Задание 4. Грузовой самолет должен пролететь с грузом из пункта А в пункт С через пункт В.Емкость бака для топлива у самолета — 300 литров.Потребление топлива
 //на 1 км в зависимости от веса груза у самолета следующее :
 // ■ до 500 кг — 1 литров / км;
 // ■ до 1000 кг — 4 литров / км;
   //■ до 1500 кг — 7 литров / км;
 // ■ до 2000 кг — 9 литров / км;
 // ■ более 2000 кг — самолет не поднимает.
  // Пользователь вводит расстояние между пунктами
 // А и В, и расстояние между пунктами В и С, а также вес
 // груза.Программа должна рассчитать какое минимальное
 //  количество топлива необходимо для дозаправки самолету
 // в пункте В, чтобы долететь из пункта А в пункт С.В случае невозможности преодолеть любое из расстояний —
 //  программа должна вывести сообщение о невозможности
 //  полета по введенному маршруту.

  //    float distanceAB, distanceBC,max=0, weight, consumption;
  //    float  tankCapacity = 300;
  //  
  //    setlocale(LC_ALL, "Russian"); 
  //
  //cout << "Емкость бака для топлива у самолета — 300 литров(или введенное значение)."      << endl <<
  //        "Потребление топлива на 1 км в зависимости от веса груза у самолета следующее :" << endl <<
  //        "до 500 кг — 1 литров / км"  << endl <<
  //        "до 1000 кг — 4 литров / км" << endl <<
  //        "до 1500 кг — 7 литров / км" << endl <<
  //        "до 2000 кг — 9 литров / км" << endl <<
  //        "более 2000 кг — самолет не поднимает" << endl;

  //   /* cout << "Ведите емкость бака для топлива у самолета:";
  //    cin >> tankCapacity1;*/

  //    cout << "Введите вес груза: ";
  //    cin >> weight;

  //     if (weight > 2000)
  //        cout << "невозможен  полет по введенному маршруту.";
  //     if (weight > 0 && weight <= 500)
  //         consumption = 1;
  //     max = tankCapacity / consumption;
  //     if (weight > 500 || weight <= 1000)
  //        consumption = 4;
  //     max = tankCapacity /  consumption;
  //     if (weight > 1000 || weight <= 1500)
  //        consumption = 7;
  //     max = tankCapacity /  consumption;
  //     if (weight > 1500 || weight <= 2000)
  //        consumption = 9;
  //     max = tankCapacity /  consumption;

  //    cout << "Введите расстояние между пунктами А и В(км): ";
  //    cin >> distanceAB;

  //    if (max <= distanceAB)
  //        cout << "Топлива не хватит до точки B";
  //    if (max > distanceAB)
  //        distanceAB = max - distanceAB;
  //   

  //    cout << "Введите расстояние между пунктами B и C(км): ";
  //    cin >> distanceBC;

  //    if (max <= distanceBC)
  //        cout << "Топлива не хватит до точки C";
  //    if (max > distanceBC)
  //        distanceBC = (distanceBC - distanceAB) * consumption;
  //    if (distanceBC < 0) 
  //        cout << "\n\nНет необходимости доливать топливо, в баке достаточно топлива.\n\n\n\n\n"; 

  //    cout << "В точке B необходимо долить " << distanceBC << " литров топлива для полёта до точки C";
  //    
          
// Домашнее задание 2
//  Задание 1. Пользователь вводит две даты(день, месяц,год в виде целых чисел).Необходимо определить и вывести количество дней между этими двумя датами.Для
// расчетов учитывать високосные года, а также корректное число дней в месяцах(март — 31, сентябрь — 30, февраль  невысокосного года — 28 и т.д.).

//setlocale(LC_ALL, "Russian");
//
//int day, day1, month, month1, year, year1, diffye, dif, diff;
//cout << "Введите день первой даты: ";
//cin >> day;
//cout << "Введите месяц первой даты: ";
//cin >> month;
//cout << "Введите год первой даты: ";
//cin >> year;
//cout << "Введите день второй даты: ";
//cin >> day1;
//cout << "Введите месяц второй даты: ";
//cin >> month1;
//cout << "Введите год второй даты: ";
//cin >> year1;

// Задание 2. Зарплата менеджера составляет 200$ + процент от продаж, продажи до 500$ — 3 %, от 500 до 1000 — 5 %,свыше 1000 — 8 % .Пользователь вводит с клавиатуры
// уровень продаж для трех менеджеров.Определить их зарплату, определить лучшего менеджера, начислить ему премию 200$, вывести итоги на экран.

   // double zp = 200,premiay=200, prodagi1=0, prodagi2=0, prodagi3=0,sum1=0,sum2=0,sum3=0;
   // double  procent1 = 3,procent2=5,procent3=8;

   // cout << "prodagi do 500$-3%       "  << endl <<
   //         "prodagi ot 500 do 1000-5%"  << endl <<
   //         "prodagi ot 1000 i bolee-8%" << endl;

   // cout << "vvedite yroven prodag dlay 1 menedgera(Kristian): ";
   // cin >> prodagi1;
   // if (prodagi1 > 0 && prodagi1 <= 500)
   //     sum1 = (prodagi1 * 3/100)+zp;
   // if (prodagi1 > 500 && prodagi1 <= 1000)
   //     sum1 = (prodagi1 * 5 / 100) + zp;
   // if (prodagi1 > 1000)   
   //     sum1 = (prodagi1 * 8 / 100) + zp;
   //cout << " Kristian zarabotal = " <<sum1<< endl;

   // cout << "vvedite yroven prodag dlay 2 menedgera(Skott): ";
   // cin >> prodagi2;
   // if (prodagi2 > 0 && prodagi2 <= 500)
   //     sum2 = (prodagi2 * 3/100) + zp;
   // if (prodagi2 > 500 && prodagi2 <= 1000)
   //     sum2 = (prodagi2 * 5 / 100) + zp;
   // if (prodagi2 > 1000)
   //     sum2 = (prodagi2 * 8 / 100) + zp;
   // cout << "Skott zarabotal = " << sum2 << endl;

   // cout << "vvedite yroven prodag dlay 3 menedgera(Lina): ";
   // cin >> prodagi3;
   // if (prodagi3 > 0 && prodagi3 <= 500)
   //     sum3 = (prodagi3 * 3 / 100) + zp;
   // if (prodagi3 > 500 && prodagi3 <= 1000)
   //     sum3 = (prodagi3 * 5 / 100) + zp;
   // if (prodagi3 > 1000)
   //     sum3 = (prodagi3 * 8 / 100) + zp;
   // cout << "Lina  zarabotala = " << sum3 << endl;

   // if (sum1 > sum2 && sum1 > sum3)
   // {
   //     sum1 += premiay;
   //     cout << "Luchshyi menedger Kristian !!" << endl <<
   //         "ego zp sostavilo " << sum1 << endl;
   // }
   // if (sum2 > sum1 && sum2 > sum3)
   // {
   //     sum2 += premiay;
   //     cout << "Luchshyi menedger Skott !!" << endl <<
   //         "ego zp sostavilo " << sum2 << endl;
   //  }
   //     
   // if (sum3 > sum2 && sum3 > sum1)
   // {
   //     sum3 += premiay;
   //     cout << "Luchshyi menedger Lina !!" << endl <<
   //         "ee zp sostavilo " << sum3 << endl;
   //  }
   //    
   // if (sum1 == sum2 && sum2 == sum3 && sum3 == sum1)
   // {
   //     cout << "pobedili VSE!!!" << endl <<
   //         "kristian " << sum1 + premiay << endl <<
   //         "Skott " << sum2 + premiay << endl <<
   //         "Lina " << sum3 + premiay << endl;
   // }
   //              


  }
    
    
  

