﻿#include <iostream>
//#include <cctype>
using namespace std;
//Тема: Логические операторы и операторы ветвлений
int main()
{//Задание 1. Пользователь вводит с клавиатуры символ.
//Определить, какой это символ : Буква, цифра, знак препинания или другое.
	//char simbol=0;
	//cout << " input simbol: ";
	//cin >> simbol;
	////
	//if (isalpha(simbol))
	//cout << "vi vveli bukvu ";
	//else if (isdigit(simbol))
	//cout << "numeral";
	//else if (ispunct(simbol)) 
	//	cout << "znak prepinaniya" << endl; 
	//else 
	//	cout << "errrorrrr" << endl;

	//ctype.h — заголовочный файл стандартной библиотеки языка программирования С, содержащий объявления функций для классификации и преобразования отдельных символов.
	//#include <ctype.h>
	//int isalnum(int c); //Если аргумент функции является либо буквой, либо цифрой, она возвращает ненулевое значение.
	//int isalpha(int c); //Возвращает ненулевое значение, если её аргумент является буквой, в противном случае возвращается нуль.
	//int isblank(int c); //Возвращает true, если с - пробел или горизонтальная табуляция (С99).
	//int iscntrl(int c); //Возвращает true, если с - управляющий символ, такой как <Ctrl+B>.
	//int isdigit(int c); //Возвращает ненулевое значение, если её аргумент является десятичной цифрой, в противном случае возвращается нуль.
	//int isgraph(int c); //Возвращает true, если с - печатаемый символ, отличный от пробела.
	//int islower(int c); //Возвращает true, если с - символ нижнего регистра.
	//int isprint(int c); //Возвращает true, если с — печатаемый символ.
	//int ispunct(int c); //Возвращает true, если с - знак препинания (любой печатаемый символ, отличный от пробела или алфавитно-цифрового символа).
	//int isspace(int c); //Возвращает true, если с — пробельный символ: пробел, новая строка,перевод страницы, возврат каретки, вертикальная табуляция, горизонтальная табуляция или, возможно, другой символ, определяемый реализацией
	//int isupper(int c); //Возвращает true, если с - символ верхнего регистра.
	//int isxdigit(int c); //Возвращает true, если с — шестнадцатеричная цифра.

	//Задание 2. Написать программу подсчета стоимости разговора для разных мобильных операторов.Пользователь вводит длительность разговора и выбирает с какого на какой оператор он звонит.Вывести стоимость на экран.

	/*double dl, op, rez, megafon = 4.5, beeline = 5.3;
	cout << "vvedite dlitelnost' razgovora v min: ";
	cin >> dl;
	cout <<
		"1.Megafon---->Beeline" << endl <<
		"2.Beeline---->Megafon" << endl <<
		"3.Megafona---->Megafon" << endl <<
		"4.Beeline----->Beeline" << endl <<
		"Vvedite cifru s kakogo na kakoi operator budete zvonit' : ";
	cin >> op;

	if (op == 1)
		{
			rez = megafon * dl;
			cout << "stoimost' razgovora s Megafon---->Beeline:  " << rez << "rub" << endl;
		}
		else if (op == 2)
		{
			rez = beeline * dl;
			cout << "stoimost' razgovora s Beeline---->Megafon:  " << rez << "rub" << endl;
		}

		else if (op == 3)
		{
			rez = megafon * dl;
			cout << "stoimost' razgovora s Megafona---->Megafon:  " << rez << "rub" << endl;
		}
		else if (op == 4)
		{
			rez = beeline * dl;
			cout << "stoimost' razgovora s Beeline----->Beeline:  " << rez << "rub" << endl;
		}
		else
			cout << "error" << endl;*/

			//Задание 3. Вася работает программистом и получает 50$ за каждые 100 строк кода.За каждое третье опоздание
			//Васю штрафуют на 20$.Реализовать меню :/надо написать;
			//■ пользователь вводит количество строк кода, написанное Васей и желаемый объем зарплаты.Посчитать,
			//сколько раз Вася может опоздать;
			//■ пользователь вводит количество строк кода и количество опозданий, определить, сколько денег заплатят
			//Васе и заплатят ли вообще.

	int str1,str2,str3,zp1=2,zp2,ko, sh=20,rez1=0,rez2=0;

	cout << "vvedite kol-vo strok koda: ";
	cin >> str2;
	cout << "vvedite gelaemyi ob'em zarplaty $: ";
	cin >> zp2;

	rez1 = zp2 / sh;
	cout << "Vasya moget opozdat' :  " << rez1 << "raz" << endl;

	cout << "vvedite kol-vo strok koda: ";
	cin >> str3;
	cout << "vvedite kol-vo opozdanii: ";
	cin >> ko;

	rez2 = str3 * zp1 - ko * sh;
	if (rez2 > 0)
		cout << "Vasi zaplatyat: " << rez2 << "$" << endl;
	else
		cout << "Vasya budet dolgen: " << rez2 << "$" << endl;
                                 


}