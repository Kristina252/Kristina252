﻿#include <iostream>
#include <iomanip>
using namespace std;
//Тема: Функции

//Задание 1. Написать функцию, которая принимает два параметра :
//основание степени и показатель степени, и вычисляет степень числа на основе полученных данных.

int powInnumber(int number, int powNum)
{
    if (powNum == 0)
        return 1;
    if (powNum == 1)
        return number;
    int result = number;
    for (int i = 0; i < powNum - 1; i++)
        result *= number;
    return result;
}

//Задание 2. Написать функцию, которая получает в качестве параметров 2 целых числа и возвращает сумму чисел
//из диапазона между ними.

int Sum(int a, int b)
{
    if (a == b)
        return  0;
    if (a > b)
        return 0;
    if (a < b)
    {
        return (a + b) * (b - a + 1) / 2;//Формула суммы арифметической прогрессии  S = (a1 + an) * n / 2.
    }  
}

////Задание 3. Число называется совершенным, если сумма
////всех его делителей равна ему самому.Напишите функцию
////поиска таких чисел во введенном интервале.

 bool Sover(int num) 
 {
   int sum = 0;
   for (int j = 1; j <= num / 2; j++)
   {
     if (num % j == 0)
     {
      sum += j;
     }
   }
   return sum == num;
 }

////Задание 4. Написать функцию, выводящую на экран
////переданную ей игральную карту.

 void card(int suit, int num)
 {
     char card[13] = { 'A','2','3','4','5','6','7','8','9','0','J','Q','K' };
     cout << " ___________________\n";
     cout << "|                   |\n";
     cout << "|                   |\n";
     if (num == 10)cout << '|' << setw(4) << "1" << card[num - 1] << "              |\n";
     else cout << '|' << setw(4) << card[num - 1] << "               |\n";
     cout << "|                   |\n";
     cout << "|                   |\n";
     cout << "|                   |\n";
     cout << "|                   |\n";
     cout << "|                   |\n";
     switch (suit)
     {
     case 1: cout << '|' << setw(12) << "HEART" << "       |\n"; break;
     case 2: cout << '|' << setw(12) << "DIAMOND" << "       |\n"; break;
     case 3: cout << '|' << setw(12) << "CLUB" << "       |\n"; break;
     case 4: cout << '|' << setw(12) << "SPADE" << "       |\n"; break;
     }
     cout << "|                   |\n";
     cout << "|                   |\n";
     cout << "|                   |\n";
     cout << "|                   |\n";
     if (num == 10)cout << "|              " << "1" << card[num - 1] << "   |\n";
     else cout << "|               " << card[num - 1] << "   |\n";
     cout << "|                   |\n";
     cout << "|___________________|\n";
 }

//// Задание 5. Написать функцию, которая определяет, 
////является ли «счастливым» шестизначное число.

 void Happy()
 {
     long a, b, a1, a2, a3, a4, a5, a6; // a - шестизначное число, а1-а6 - цыфри числа, которые получим путем деления с остачей
     cout << "Enter a six-digit number: ";
     cin >> a;
     b = a;
     a1 = a / 100000; b = a % 100000;
     a2 = b / 10000; b %= 10000;
     a3 = b / 1000; b %= 1000;
     a4 = b / 100; b %= 100;
     a5 = b / 10; b %= 10;
     a6 = b;
     if (99999 >= a || a > 999999)
         cout << "Ouch! You entered uncorrect number!" << endl;
     else

         if ((a1 + a2 + a3) == (a4 + a5 + a6))
             cout << "You entered lucky number! Congratulations!" << endl;
         else
         {
             ((a1 + a2 + a3) != (a4 + a5 + a6));
             cout << "You have a bad day. Sorry..." << endl;
         }

 }

//Тема: Функции.Передача массивов внутрь функции

////Задание 1. Написать функцию, реализующую алгоритм
////линейного поиска заданного ключа в одномерном массиве.

 //вывод массива на экран
 void showArr(int arr[], int arrSize)
 {
     for (int i = 0; i < arrSize; i++)
     {
         cout << setw(4) << arr[i];
         if ((i + 1) % 10 == 0)
         {
             cout << endl;
         }

     }
     cout << endl << endl;
 }

 //линейный поиск
 int linSearch(int arr[], int requiredKey, int arrSize)
 {
     for (int i = 0; i < arrSize; i++)
     {
         if (arr[i] == requiredKey)
             return i;
     }
     return -1;
 }

////Задание 2. Написать функцию, реализующую алгоритм
////бинарного поиска заданного ключа в одномерном массиве.
// функция с алгоритмом двоичного поиска 

 int Search_Binary(int arr[], int left, int right, int key)
 {
     int midd = 0;
     while (1)
     {
         midd = (left + right) / 2;

         if (key < arr[midd])       // если искомое меньше значения в ячейке
             right = midd - 1;      // смещаем правую границу поиска
         else if (key > arr[midd])  // если искомое больше значения в ячейке
             left = midd + 1;    // смещаем левую границу поиска
         else                       // иначе (значения равны)
             return midd;           // функция возвращает индекс ячейки

         if (left > right)          // если границы сомкнулись 
             return -1;
     }
 }

////Задание 3. Написать функцию для перевода числа, записанного в двоичном виде, 
////в десятичное представление.

 void Dvoich()
 {
     setlocale(LC_ALL, "rus");
     int j = 1;
     int Chislo = 0;
     char str[64]; // строка для числа в 2 СС
     cout << "Введите число в двоичной системе счисления:\n";
     cin >> str;
     for (int i = 0; i < strlen(str); i++)
     {
         Chislo *= 2;
         Chislo += str[i] - '0';  // '0'-'0' равно 0, '1'-'0' Равно 1
     }
     cout << "В десятичной системе счисления это будет: " << Chislo << endl;
 }
int main()
{
    setlocale(LC_ALL, "RUS");
    /*int number, powNum; //первая функция
    cout << "Enter number : ";
    cin >> number;
    cout << "Enter pow : ";
    cin >> powNum;
    cout << "Rezult = " << powInnumber(number, powNum) << endl;*///первая функция

    /*int a=0, b=0; //вторая функция
    cout << "Введите первое число: ";
    cin >> a;
    cout << "Введите второе число: ";
    cin >> b;
    cout << "сумма чисел из диапозона между ними = " << Sum(a, b);*/ //вторая функция

    /*int num = 0; //совершенные числа третья функция
    cout << "Vvedite chislo: ";
    cin >> num;

    cout << "Vyvod sovershennyh chisel: " << endl;

        for (int i = 1; i < num; ++i)
        {
            if (Sover(i)) 
            {
                cout << i << endl;
            }
        }*/
    

    /*int a, s;//игральная карта
    cout << "Enter card\n1 - Ace \n2 - Two\n3 - Three\n4 - Four\n5 - Five\n6 - Six\n7 - Seven\n8 - Eight\n9 - Nine\n10 - Ten\n11 - Jacket\n12 - Quin\n13 - King" << endl;
    cin >> a;
    cout << "\n\t\t\tCard suits\n1. Heart.\n2. Diamond\n3. Club\n4. Spade\n";
    cout << "Input a card suit: ";
    cin >> s;
    card(s, a);*/

    /*Happy();*///счастливое число

    //setlocale(LC_ALL, "rus");//линейный поиск в массиве
    //const int arrSize = 50;
    //int arr[arrSize];
    //int requiredKey = 0; // искомое значение (ключ)
    //int nElement = 0; // номер элемента массива
    //srand(time(NULL));

    ////запись случ. чисел в массив от 1 до 50
    //for (int i = 0; i < arrSize; i++)
    //{
    //    arr[i] = 1 + rand() % 50;
    //}

    //showArr(arr, arrSize);

    //cout << "Какое число необходимо искать? ";
    //cin >> requiredKey; // ввод искомого числа

    ////поиск искомого числа и запись номера элемента
    //nElement = linSearch(arr, requiredKey, arrSize);

    //if (nElement != -1)
    //{
    //    //если в массиве найдено искомое число - выводим индекс элемента на экран
    //    cout << "Значение " << requiredKey << " находится в ячейке с индексом: " << nElement << endl;
    //}
    //else
    //{
    //    //если в массиве не найдено искомое число
    //    cout << "В массиве нет такого значения" << endl;
    //}

    //setlocale(LC_ALL, "rus");//бинарный поиск в массиве
    //const int SIZE = 12;
    //int array[SIZE] = {};
    //int key = 0;
    //int index = 0; // индекс ячейки с искомым значением

    //for (int i = 0; i < SIZE; i++) // заполняем и показываем массив
    //{
    //    array[i] = i + 1;
    //    cout << array[i] << " | ";
    //}

    //cout << "\n\nВведите любое число: ";
    //cin >> key;

    //index = Search_Binary(array, 0, SIZE, key);

    //if (index >= 0)
    //    cout << "Указанное число находится в ячейке с индексом: " << index << "\n\n";
    //else
    //    cout << "В массиве нет такого числа!\n\n";

   /* Dvoich();*/

}

