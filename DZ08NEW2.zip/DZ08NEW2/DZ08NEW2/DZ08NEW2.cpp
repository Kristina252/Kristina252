﻿#include <iostream>
//#include <iomanip>
//#include <string.h>
//#include <windows.h>
//#include <stdlib.h>//?
#include <ctime>//?
using namespace std;


int main()
{
	//циклы
	//Задание 1. Написать программу, которая выводит на экран линию заданным символом, вертикальную или
	//горизонтальную, причем линия может выводиться быстро, нормально и медленно.Общение с пользователем организовать через меню.

	/*char symbol, liniay, speed;
	int medleno, normalno, bystro, size;

	cout << "vvedite razmer linii: ";
	cin >> size;
	cout << "Vvedite simvol: ";
	cin >> symbol;
	cout << "1=Vertikalnaay ili 2=gorizontalnaya : ";
	cin >> liniay;
	cout << "m=Medlenno ,n=Normalno ,b=Bistro: ";
	cin >> speed;

	switch (liniay)
	{
	case 'v':
	{
		for (int i = 0; i < size; i++)
		{
			if (speed == 'm')
			{
				Sleep(1000);
				cout << setw(3) << symbol << endl;
			}

			else if (speed == 'n')
			{
				Sleep(400);
				cout << setw(3) << symbol << endl;
			}

			else if (speed == 'b')
			{
				Sleep(20);
				cout << setw(3) << symbol << endl;
			}
		}
	}
	break;
	case'g':
	{
		for (int i = 0; i < size; i++)
		{
			if (speed == 'm')
			{
				Sleep(1000);
				cout << setw(3) << symbol;
			}

			else if (speed == 'n')
			{
				Sleep(400);
				cout << setw(3) << symbol;
			}

			else if (speed == 'b')
			{
				Sleep(20);
				cout << setw(3) << symbol;
			}
		}
	}
	break;
	}*/
	//Тема: Циклы
	//Задание 2. Написать игру «Кубики».Пользователь и компьютер по очереди бросают 2 кубика.Победитель — тот,
	//у кого по результатам 3х бросков сумма больше.Предусмотреть красивый интерфейс игры.

	/*int igrok20 = 0, igrok21 = 0, igrok22 = 0, brosok1 = 0, brosok2 = 0, brosok3 = 0, komp1 = 0;
	int hod = 3, rand1 = 0, rand2 = 0,  rez1 = 0, rez2 = 0;
	char s;

	srand((unsigned int)time(NULL));
	setlocale(LC_ALL, "Rus");

	cout << "\t\t\t *  * *** *** ****    *  *  *   *  ***    *  *  *  *   *   *   " << endl;
	cout << "\t\t\t * ** *   *** ****    **    * * *  ** **  * **  **     *  **   " << endl;
	cout << "\t\t\t ** * *   *   *  *    *  *    *    * * *  ** *  *  *   **  *  \n\n\n" << endl;


	cout << "\t\t\t\t\t*******************************" << endl;
	cout << "\t\t\t\t\t*******************************" << endl;
	cout << "\t\t\t\t\t**                           **" << endl;
	cout << "\t\t\t\t\t**     *               *     **" << endl;
	cout << "\t\t\t\t\t**    ***             ***    **" << endl;
	cout << "\t\t\t\t\t**     *               *     **" << endl;
	cout << "\t\t\t\t\t**                           **" << endl;
	cout << "\t\t\t\t\t**                           **" << endl;
	cout << "\t\t\t\t\t**       ************        **" << endl;
	cout << "\t\t\t\t\t**                           **" << endl;
	cout << "\t\t\t\t\t*******************************" << endl;
	cout << "\t\t\t\t\t*******************************\n\n\n\n\n" << endl;

	do
	{
		cout << " \t\t\t\t для начала игры нажмите букву (s+Enter):  \n\n";
		cin >> s;

		if (s == 's')
		{
			cout << "\t\t\tCечас будут выброшены два кубика.Один кубик будет компьютера(1),а другой ваш(2)." << endl <<
				"\t\t\t\tУ кого цифра выпадет больше,тот и ходит первым  ! " << endl <<
				"\t\t\tПримечание!Цифры не должны быть одинаковы\n\n" << endl;
			do
			{
				cout << "\t\t\t\tВыбрасывается кубик компьютерa(1)\n " << endl;
				Sleep(1000);

				rand1 = rand()% 6 + 1;

				cout << "\t\t\t\t\t*******************************" << endl;
				cout << "\t\t\t\t\t*******************************" << endl;
				cout << "\t\t\t\t\t**                           **" << endl;
				cout << "\t\t\t\t\t**     *                     **" << endl;
				cout << "\t\t\t\t\t**                           **" << endl;
				cout << "\t\t\t\t\t**       (" << rand1 << ")\t\t     **" << endl;
				cout << "\t\t\t\t\t**                           **" << endl;
				cout << "\t\t\t\t\t**                           **" << endl;
				cout << "\t\t\t\t\t**                           **" << endl;
				cout << "\t\t\t\t\t**                           **" << endl;
				cout << "\t\t\t\t\t*******************************" << endl;
				cout << "\t\t\t\t\t*******************************\n\n\n\n\n" << endl;

				cout << "\t\t\t\tВыбрасывается ваш кубик (2)\n " << endl;
				Sleep(1000);

				rand2 = rand()% 6 + 1;

				cout << "\t\t\t\t\t*******************************" << endl;
				cout << "\t\t\t\t\t*******************************" << endl;
				cout << "\t\t\t\t\t**                           **" << endl;
				cout << "\t\t\t\t\t**                           **" << endl;
				cout << "\t\t\t\t\t**                           **" << endl;
				cout << "\t\t\t\t\t**       (" << rand2 << ")\t\t     **" << endl;
				cout << "\t\t\t\t\t**                           **" << endl;
				cout << "\t\t\t\t\t**                           **" << endl;
				cout << "\t\t\t\t\t**           *               **" << endl;
				cout << "\t\t\t\t\t**                           **" << endl;
				cout << "\t\t\t\t\t*******************************" << endl;
				cout << "\t\t\t\t\t*******************************\n\n\n\n\n" << endl;

				if (rand1 > rand2)
				{
					cout << "\t\t\t\tПервый ход у компьютера (1)" << endl;

					for (int i = 1; i < hod + 1; i++)
					{
						Sleep(1000);
						komp1 = rand() % 6 + 1;
						cout << " ход= " << i << " цифра= " << komp1 << endl;
						rez1 += komp1;
					}

					Sleep(1000);
					cout << "\t\t\t\t\tСумма бросков компьютера \n\n " << endl;
					cout << "\t\t\t\t\t*******************************" << endl;
					cout << "\t\t\t\t\t*******************************" << endl;
					cout << "\t\t\t\t\t**                           **" << endl;
					cout << "\t\t\t\t\t**       *                   **" << endl;
					cout << "\t\t\t\t\t**                           **" << endl;
					cout << "\t\t\t\t\t**       (" << rez1  << ")\t\t     **" << endl;
					cout << "\t\t\t\t\t**                           **" << endl;
					cout << "\t\t\t\t\t**                           **" << endl;
					cout << "\t\t\t\t\t**                           **" << endl;
					cout << "\t\t\t\t\t**                           **" << endl;
					cout << "\t\t\t\t\t*******************************" << endl;
					cout << "\t\t\t\t\t*******************************\n\n\n\n\n" << endl;

					cout << "Теперь бросаете вы !" << endl;

					do
					{
						cout << "Для того,чтобы сделать первый бросок,нажмите (1+Enter): ";
						cin >> brosok1;

						if (brosok1 == 1)
						{
							igrok20 = rand() % 6 + 1;
							cout << " Цифра = " << igrok20 << endl;

						}

					} while (brosok1 != 1);

					do
					{
						cout << "Для того,чтобы сделать второй бросок,нажмите (2+Enter): ";
						cin >> brosok2;

							igrok21 = rand() % 6 + 1;
							cout << " Цифра = " << igrok21 << endl;


					} while (brosok2 != 2);
					do
					{
						cout << "Для того,чтобы сделать третий бросок,нажмите (3+Enter): ";
						cin >> brosok3;

						if (brosok3 == 3)
						{
							igrok22 = rand() % 6 + 1;
							cout << " Цифра = " << igrok22<< endl;

						}

						rez2 = igrok20 + igrok21 + igrok22;

						Sleep(1000);
						cout << "\t\t\t\t\tСумма всех ваших бросков \n\n "<< endl;
						cout << "\t\t\t\t\t*******************************" << endl;
						cout << "\t\t\t\t\t*******************************" << endl;
						cout << "\t\t\t\t\t**                           **" << endl;
						cout << "\t\t\t\t\t**                           **" << endl;
						cout << "\t\t\t\t\t**                           **" << endl;
						cout << "\t\t\t\t\t**       (" << rez2 << ")\t\t     **" << endl;
						cout << "\t\t\t\t\t**                           **" << endl;
						cout << "\t\t\t\t\t**                           **" << endl;
						cout << "\t\t\t\t\t**           *               **" << endl;
						cout << "\t\t\t\t\t**                           **" << endl;
						cout << "\t\t\t\t\t*******************************" << endl;
						cout << "\t\t\t\t\t*******************************\n\n\n\n\n" << endl;

						if (rez1 < rez2)
							cout << "\t\t\t\t\tВы победили!!!!!!УРА!!!УРА!!!УРА!!!" << endl;
						else if (rez1 > rez2)
							cout << "\t\t\t\t\tКомпьютер тебя сделал ,ничтожество!Играй опять!" << endl;
						else
							cout << "\t\t\t\t\tПобедила дружба и жевачка " << endl;


					} while (brosok3 != 3);
				}


				else if (rand1 < rand2)
				{
					cout << "\t\t\t\t\t\tПервый ход у вас (2) " << endl;

					do
					{
						cout << "Для того,чтобы сделать первый бросок,нажмите (1+Enter): ";
						cin >> brosok1;

						if (brosok1 == 1)
						{
							igrok20 = rand() % 6 + 1;
							cout << " Цифра = " << igrok20 << endl;
						}

					} while (brosok1 != 1);

					do
					{
						cout << "Для того,чтобы сделать второй бросок,нажмите (2+Enter): ";
						cin >> brosok2;

						if (brosok2 == 2)
						{
							igrok21 = rand() % 6 + 1;
							cout << " Цифра = " << igrok21 << endl;

						}

					} while (brosok2 != 2);
					do
					{
						cout << "Для того,чтобы сделать третий бросок,нажмите (3+Enter): ";
						cin >> brosok3;

						if (brosok3 == 3)
						{
							igrok22 = rand() % 6 + 1;
							cout << " Цифра = " << igrok22 << endl;

						}

						rez2 = igrok20 + igrok21 + igrok22;
						Sleep(1000);

						cout << "\t\t\t\t\tСумма всех ваших бросков \n\n " << endl;
						cout << "\t\t\t\t\t*******************************" << endl;
						cout << "\t\t\t\t\t*******************************" << endl;
						cout << "\t\t\t\t\t**                           **" << endl;
						cout << "\t\t\t\t\t**                           **" << endl;
						cout << "\t\t\t\t\t**                           **" << endl;
						cout << "\t\t\t\t\t**       (" << rez2 << ")\t\t     **" << endl;
						cout << "\t\t\t\t\t**                           **" << endl;
						cout << "\t\t\t\t\t**                           **" << endl;
						cout << "\t\t\t\t\t**           *               **" << endl;
						cout << "\t\t\t\t\t**                           **" << endl;
						cout << "\t\t\t\t\t*******************************" << endl;
						cout << "\t\t\t\t\t*******************************\n\n\n\n\n" << endl;

					} while (brosok3 != 3);

					cout << "Теперь ход компьютера!" << endl;

					for (int i = 1; i < hod + 1; i++)
					{
						komp1 = rand() % 6 + 1;
						cout << " ход= " << i << " цифра= " << komp1 << endl;
						rez1 += komp1;
					}
					Sleep(1000);

					cout << "\t\t\t\t\tСумма бросков компьютера \n\n " << endl;
					cout << "\t\t\t\t\t*******************************" << endl;
					cout << "\t\t\t\t\t*******************************" << endl;
					cout << "\t\t\t\t\t**                           **" << endl;
					cout << "\t\t\t\t\t**       *                   **" << endl;
					cout << "\t\t\t\t\t**                           **" << endl;
					cout << "\t\t\t\t\t**       (" << rez1 << ")\t\t     **" << endl;
					cout << "\t\t\t\t\t**                           **" << endl;
					cout << "\t\t\t\t\t**                           **" << endl;
					cout << "\t\t\t\t\t**                           **" << endl;
					cout << "\t\t\t\t\t**                           **" << endl;
					cout << "\t\t\t\t\t*******************************" << endl;
					cout << "\t\t\t\t\t*******************************\n\n\n\n\n" << endl;

					if (rez1 < rez2)
						cout << "\t\t\t\tВы победили!!!!!!УРА!!!УРА!!!УРА!!!" << endl;

					else if (rez1 > rez2)
						cout << "\t\t\t\tКомпьютер тебя сделал ,ничтожество!Играй опять!" << endl;

					else
						cout << "\t\t\t\t\t Победила дружба и жевачка " << endl;
				}

			} while (rand1 == rand2);
		}

	} while (s != 's');*/

	//Тема: Массивы одномерные
	//Задание 1. В одномерном массиве, заполненном случайными числами, определить минимальный и максимальный элементы.

 //int const size = 10;
 //int rez = 0,max=0,min=0;
 //bool tut;//true

 //int arr[size];

	//srand((unsigned int)time(NULL));

	//for (int i = 0; i < size;)
	//{
	//	tut = false;
	//	int newRV = rand() % +20;

	//	for (int j = 0; j < i; j++)
	//	{
	//		if (arr[j] == newRV)
	//		{
	//			tut = true;
	//			break;
	//		}
	//	}
	//	if (!tut)//если выражение фолс !-конвертирует из истины в ложь
	//	{
	//		arr[i] = newRV;
	//		i++;
	//	}
	//}

	//for (int i = 0; i < size; i++)
	//{
	//	cout << setw(3) << arr[i] << "|";
	//}
	//cout << endl;
	//

	//min = arr[0];//помещаем значения первого элемента
	//max = arr[0];//массива во второй

	//for (int i = 1; i < size; i++)
	//{
	//	if (max < arr[i]) //если значение элемента больше значения переменной max, то записываем это значение в переменную 
	//		max = arr[i];//аналогично и для min

	//	if (min > arr[i])
	//		min = arr[i];
	//}

	//cout << "Min: " << min << endl;
	//cout << "Max: " << max << endl;



	//Задание 2. Пользователь вводит прибыль фирмы за год (12 месяцев).
	//Затем пользователь вводит диапазон(например, 3 - м и 6 - м месяцем).
	//Необходимо определить месяц, в котором прибыль была максимальна и месяц, в котором прибыль была минимальна с учетом выбранного диапазона.

	//const int SIZE = 12;
	//int arr[SIZE]{NULL};//помещаем нули в массив,вместо мусора .можно написать 0,или оставить фигурные скобки пустыми
	//int max=0,min=0,sum=0,one=0,two=0;//заводим переменные для мин и макс в массиве
 //   setlocale(LC_ALL, "rus");

	//cout << " size off arr = " << sizeof(arr)<<"\n"<<endl ;//просто смотрю размер массива в байтах(набиваю для себя,запоминаю)

	//for (int i = 0; i < SIZE; i++)
	//{
	//	cout << " месяц - ( " << i+1 << ")  введите прибыль за месяц \t: " ;
	//	cin >>arr[i] ; //запоняем массив значениями 
	//}

	//cout <<"\n\n ВЫВОДИМ ПРИБЫЛЬ ЗА КАЖДЫЙ МЕСЯЦ\n\n" <<endl;

	//for (int i = 0; i < SIZE; i++)
	//{
	//	cout << " месяц - ( " << i +1<< ")  прибыль в этом месяце \t: "<<arr[i]<<endl;//выводим масссив
	//	sum += arr[i];
	//}

	//cout <<"\nПрибыль фирмы за год составляет: "<< sum <<"\n";

	//min = arr[0];
	//max = arr[0];

	//for (int i = 0; i < SIZE; i++)
	//{
	//	if (max < arr[i]) //если значение элемента больше значения переменной max, то записываем это значение в переменную 
	//		max = arr[i];//аналогично и для min

	//	if (min > arr[i])
	//		min = arr[i];
	//}
	//cout <<"\n"<< endl;

	//cout << "За весь период Min прибыль состовляет: " << min <<endl;
	//cout << "За весь период Max прибыль состовляет: " << max <<"\n"<<endl;

	//cout << "ВВедите необходимый диапозон между месяцами" << endl<<
	//    "1-январь   " << endl <<
	//	"2-февраль   " << endl <<
	//	"3-март      " << endl <<
	//	"4-апрель    " << endl <<
	//	"5-май       " << endl <<
	//	"6-июнь      " << endl <<
	//	"7-июль      " << endl <<
	//	"8-август    " << endl <<
	//	"9-сентябрь  " << endl <<
	//	"10-октябрь  " << endl <<
	//	"11-ноябрь   " << endl <<
	//	"12-декабрь\n" << endl;
	//	  
	// cout << " С : ";
	// cin >> one;
 //    cout << " ПО : ";
	// cin >> two;

	// one -= 1;
	// two -= 1;

	// for (int i = one; i <= two; i++)
	// {
	//	 cout <<" i  " << i+1 << " arr  " << arr[i]<<endl;
	// }

	// min = arr[0];
	// max = arr[0];

	// for (int i = one; i <= two; i++)
	// {
	//	 if (max < arr[i]) //если значение элемента больше значения переменной max, то записываем это значение в переменную 
	//		 max = arr[i];//аналогично и для min

	//	 if (min > arr[i])
	//		 min = arr[i];
	// }
	// cout << "\n" << endl;

	// cout << "Min прибыль состовляет: " << min << endl;
	// cout << "Max прибыль состовляет: " << max << "\n" << endl;



	//Задание3.В одномерном массиве, состоящем из N вещественных чисел вычислить:
			 //■ Сумму отрицательных элементов.
			 //■ Произведение элементов, находящихся между min и max элементами.
			 //■ Произведение элементов с четными номерами.
			 //■ Сумму элементов, находящихся между первым и последним отрицательными элементами.

	const int N = 10;
	int arr[N]{ NULL };
	int sum1 = 0, sum2 = 0, sum3 = 0, pr1 = 1, pr2 = 1, pr3 = 1, min = 0, max = 0;//pr1=1 а не нулю,потому что нам нужно умножение.если на нольь то все будет ноль.

	setlocale(LC_ALL, "rus");
	srand((unsigned int)time(NULL));//срэнд для того чтобы каждый раз были рэндомные значения.без него рандом будет один раз,остальные итерации аналогичные


	for (int i = 0; i < N; i++)
	{
		arr[i] = rand() % 20 - 10;
		cout << "arr1 | " << arr[i] << " | ";
	}
	cout << endl;

	for (int i = 0; i < N; i++)//■Сумма отрицательных элементов
	{
		if (arr[i] < 0)
		{
			cout << " arr2| " << arr[i] << " | "; //все отрицательные числа
		}
		sum1 += arr[i];//присваеваем сум все отрицательные числа .складываем их
	}
	cout << endl;
	cout << " sum | " << sum1 << " | " << endl;//сумма отрицательных

	min = arr[0];
	max = arr[0];

	int minindex=0, maxindex=0;// запоминаем индекс мин и макс
	for (int i = 0; i < N; i++)
	{
		if (arr[i] < min)//слева с чем сравниваю
		{
			min = arr[i];
			minindex = i;
		}
		if (arr[i] > max)
		{
			max = arr[i];
			maxindex = i;
		}
	}

	cout << " min el-t: " << min << endl;
	cout << " max el-t: " << max << endl;

	int tempindex;
	if (minindex > maxindex)//свап если индекс мин будет больше максимума
	{
		tempindex = minindex;
		minindex = maxindex;
		maxindex = tempindex;
	}

	for (int i = minindex; i <= maxindex; i++)//■ Произведение элементов, находящихся между min и max элементами.
	{
		pr1 *= arr[i];
	}
	cout << " Произведение всех элементов мин-макс-      : " << pr1 << endl;

	for (int i = 0; i < N; i++)//■ Произведение элементов с четными и нечетными номерами.
	{
		if (arr[i] % 2 == 0)
			pr2 *= arr[i];//четные 
		else
			pr3 *= arr[i];//нечетные
	}

	cout << " Произведение элементов с четными номерами  : " << pr2 << endl;
	cout << " Произведение элементов с нечетными номерами: " << pr3 << endl;

	int index1,index2;
	bool count = false;

	for (int i = 0; i < N; i++)//■ Сумму элементов, находящихся между первым и последним отрицательными элементами.
	{
		if (arr[i] < 0)
		{    
			if (count == false)
			{
				index1 = i;
			}
			else
				index2 = i;

			count=true;
		}
	}

	for (int i = index1; i <= index2; i++)
	{
		sum3 += arr[i];
	}
	cout << " Сумму элементов, находящихся между первым и последним отрицательными элементами: " <<sum3<< endl;



}

