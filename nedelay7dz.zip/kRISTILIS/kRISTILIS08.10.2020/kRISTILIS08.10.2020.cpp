﻿#include <iostream>
using namespace std;

int main()
{


	//неделя 7+
//задание 2-написать программу которая выводит шахматную доску
	int x = 8;
	int a = x;

	for (int i = 0; i < x; i++)
	{
		for (int i = 0; i < a; i++)
			cout << "---###";
		cout << endl;

		for (int i = 0; i < a; i++)
			cout << "###---";
		cout << endl;
	}

	//неделя 7
	//Задание 1. Вывести на экран фигуры заполненные звездочками.
	//Диалог с пользователем реализовать при помощи меню.

	char bukva;

	cout << "vvdite bukvu "; cin >> bukva;


	if (bukva == 'a')//треугольник правый верхний угол
	{
		int y;
		cout << "vvdite kol. strok: "; cin >> y;

		int a = 0;
		int b = y;

		for (int i = 0; i < y; i++)
		{
			for (int i = 0; i < a; i++)
			{
				cout << "  ";
			}
			for (int i = 0; i < b; i++)
			{
				cout << "* ";
			}
			cout << endl;
			b--;
			a++;
		}
	}
	if (bukva == 'b')//треугольник левый нижний угол
	{
		int x = 1;
		int y;

		cout << "vvdite kol. strok: "; cin >> y;

		for (int j = 0; j < y; j++)
		{
			for (int i = 0; i < x; i++)
			{
				cout << "* ";
			}

			cout << endl;
			x++;
		}


	}

	if (bukva == 'v') //верхний треугольник вершина вниз
	{
		int x = 3;
		cout << "vvdite kol. strok: "; cin >> x;

		if (x % 2 == 0) x++;

		int a = 0;
		int b = x + 2;

		for (int i = 0; i < x; i++)
		{
			for (int i = 0; i < a; i++) cout << "  ";

			for (int i = 0; i < b; i++) cout << "* ";

			cout << endl;
			a++;
			b = b - 2;
		}
	}
	if (bukva == 'g')//нижний треугольник вешина вверх
	{
		int x;
		cout << "vvdite kol. strok: "; cin >> x;

		if (x % 2 == 0) x++;

		int a = x - 1;
		int b = 1;

		for (int i = 0; i < x; i++)
			cout << endl;

		for (int i = 0; i < x; i++)
		{
			for (int i = 0; i < a; i++) cout << "  ";
			for (int i = 0; i < b; i++) cout << "* ";
			cout << endl;

			a--;
			b = b + 2;
		}
	}

	if (bukva == 'd')//песочные часы
	{
		int x;
		cout << "vvdite kol. strok: "; cin >> x;

		if (x % 2 == 0) x++;

		int a = 0;
		int b = x + 2 + 2;

		for (int i = 0; i < x - 1; i++)
		{
			for (int i = 0; i < a; i++) cout << "  ";
			for (int i = 0; i < b; i++) cout << "* ";

			cout << endl;
			a++;
			b = b - 2;
		}

		a = x - 1;
		b = 1;

		for (int i = 0; i < x; i++)
		{
			for (int i = 0; i < a; i++) cout << "  ";
			for (int i = 0; i < b; i++) cout << "* ";
			cout << endl;

			a--;
			b = b + 2;
		}
	}
	if (bukva == 'i')//верхний левыйугол боковой треугольник 
	{
		int x = 5;
		cout << "vvdite kol. strok: "; cin >> x;


		int y = x;

		for (int j = 0; j < y; j++)
		{
			for (int i = 0; i < x; i++)
			{
				cout << "* ";
			}

			cout << endl;
			x--;
		}
	}
	if (bukva == 'k')//нижний правый угол боковой треугольник
	{
		int x;
		cout << "vvdite kol. strok: "; cin >> x;

		if (x % 2 == 0) x++;

		int a = x - 1;
		int b = 1;

		for (int i = 0; i < 10; i++)
		{
			for (int i = 0; i < a; i++) cout << "  ";
			for (int i = 0; i < b; i++) cout << "* ";
			cout << endl;

			b++;
			a--;
		}
	}

	if (bukva == 'j')//треугольник слева
	{
		int x;
		cout << "vvdite kol. strok: "; cin >> x;

		x = x / 2;

		int a = 1;

		for (int i = 0; i < x; i++)
		{
			for (int i = 0; i < a; i++)
			{
				cout << "* ";
			}
			cout << endl;
			a++;
		}

		for (int i = 0; i < x + 1; i++)
		{
			for (int i = 0; i < a; i++)
			{
				cout << "* ";
			}
			cout << endl;
			a--;
		}
	}
	if (bukva == 'z')//треугольник справа
	{
		int x;
		cout << "vvdite kol. strok: "; cin >> x;

		int a = 1;
		int b = x;

		x = x / 2;

		for (int i = 0; i < x; i++)
		{
			for (int i = 0; i < b; i++)
			{
				cout << "  ";
			}
			for (int i = 0; i < a; i++)
			{
				cout << "* ";
			}
			cout << endl;
			a++;
			b--;
		}



		for (int i = 0; i < x + 1; i++)
		{
			for (int i = 0; i < b; i++)
			{
				cout << "  ";
			}

			for (int i = 0; i < a; i++)
			{
				cout << "* ";
			}
			cout << endl;
			a--;
			b++;
		}
	}

	if (bukva == 'e')//треугольник слева и справа
	{
		int x;
		cout << "vvdite kol. strok: "; cin >> x;

		int a = 1;
		int b = x - 1;

		x = x / 2;

		for (int i = 0; i < x; i++)
		{
			for (int i = 0; i < a; i++)
			{
				cout << "*";
			}
			for (int i = 0; i < b; i++)
			{
				cout << " ";
			}
			for (int i = 0; i < a; i++)
			{
				cout << "*";
			}
			cout << endl;
			a++;
			b--;
			b--;
		}

		for (int i = 0; i < 2 * a - 1; i++)
		{
			cout << "*";
		}
		cout << endl;

		b++;
		b++;
		a--;

		for (int i = 0; i < x; i++)
		{
			for (int i = 0; i < a; i++)
			{
				cout << "*";
			}
			for (int i = 0; i < b; i++)
			{
				cout << " ";
			}
			for (int i = 0; i < a; i++)
			{
				cout << "*";
			}
			cout << endl;
			a--;
			b++;
			b++;
		}
	}


	//неделя 7!!!
	//задание 1-пользователь вводит число.
	//определить количество цифр в этом числе,посчитать их сумму и среднее арифметическое.
	//определить кол-во нулей в этом числе.общение организовать через меню.

	int a;
	cout << "vvedite 4islo: " << endl;
	cin >> a;
	int sr = a, b = 0, c = 0, sum = 0;
	int  n = 1;

	while (a)
	{
		if (a % 10 == 0)
			c++;
		a /= 10;
	}
	cout << "kol-vo nulei == " << c << endl;

	for (n = 0; sr > 0; n++)
	{
		sum += sr % 10;
		sr /= 10;
	}

	cout << "kol-vo cifr =   " << n << endl;
	cout << "sum         =   " << sum << endl;
	cout << "sredn arifm =   " << (double)sum / n << endl;;


	return 0;

}